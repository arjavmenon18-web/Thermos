"""Optional localhost launcher. Python standard library only; no pip install needed."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import threading
import webbrowser

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description='Run THERMOS locally')
    parser.add_argument('--port',type=int,default=8501)
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    handler=partial(SimpleHTTPRequestHandler,directory=str(root))
    try:
        server=ThreadingHTTPServer(('127.0.0.1',args.port),handler)
    except OSError as exc:
        raise SystemExit(f'Could not use port {args.port}: {exc}\nTry: python serve.py --port 8502')
    url=f'http://127.0.0.1:{args.port}'
    print(f'THERMOS is running at {url}\nKeep this window open. Press Ctrl+C to stop.')
    if not args.no_browser:
        threading.Timer(.4,lambda:webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nTHERMOS stopped.')
    finally:
        server.server_close()
