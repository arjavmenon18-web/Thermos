/* Generate entire independent synthetic episodes with the same public plant equations. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),E=require('../assets/engine.js');
const rand=E.rng(20261021),rows=[];
for(let episode=0;episode<180;episode++){
  const c=E.config({outside:22+rand()*27,demand:35+rand()*60,restriction:rand()*.42,heatwave:episode%2===0});
  let temps=Array.from({length:E.N},()=>22+rand()*10);
  for(let t=0;t<24;t++){
    const supply=[20,22,24][Math.floor(rand()*3)],fan=[.45,.7,1][Math.floor(rand()*3)];
    const control={supply,fan,mode:'dry'},outside=E.ambient(c,t*3);
    const raw=E.rawDemand(c,t*3),loads=E.balanceLoads(raw,rand()*Math.min(2,12-E.sum(raw)),rand()>.5?'spread':'original').loads;
    // Freeze the candidate controls/loads for the 15-minute prediction label.
    const future=E.forecast(temps,loads,control,outside,c,null);
    for(let i=0;i<E.N;i++)rows.push({episode,x:E.features(temps[i],loads[i],E.neighbor(loads,i),control,outside,E.restriction(c,i)),y:future[i]-temps[i]});
    temps=E.physics(temps,loads,control,outside,c);
  }
}
const dest=process.argv[2]||path.join(__dirname,'dataset.json');fs.writeFileSync(dest,JSON.stringify(rows));
console.log(JSON.stringify({episodes:180,rows:rows.length,output:dest}));
