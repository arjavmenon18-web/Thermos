'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const E=require('../assets/engine.js'),M=require('../assets/model.js');
const near=(a,b,tol=1e-6)=>assert.ok(Math.abs(a-b)<tol,`${a} vs ${b}`);
test('Browser forest matches scikit-learn reference predictions',()=>{
  const refs=JSON.parse(fs.readFileSync(path.join(__dirname,'../data/inference_reference.json')));
  for(const r of refs)near(E.forestPredict(M,r.x),r.prediction,1e-5);
});
test('Movable workload is conserved and rack capacity is respected',()=>{
  const rand=E.rng(8);
  for(let n=0;n<100;n++){
    const raw=Array.from({length:12},()=>.15+rand()*.8),extra=Math.min(2,12-E.sum(raw));
    for(const style of ['original','spread','consolidate']){
      const q=E.balanceLoads(raw,extra,style);near(E.sum(q.loads),E.sum(raw)+extra);
      q.loads.forEach((v,i)=>{assert.ok(v<=1+1e-7);assert.ok(v>=raw[i]*.45-1e-7);});
      near(q.unserved,0);
    }
  }
});
test('Hidden truth does not leak into the observation estimator',()=>{
  const c=E.config({sensors:4}),a=E.initial(c),b=E.initial(c);
  const hidden=Array.from({length:12},(_,i)=>i).filter(i=>!E.sensorMask(c,0).includes(i));
  hidden.forEach(i=>b.temps[i]+=20);
  assert.deepEqual(E.observe(a,c),E.observe(b,c));
});
test('Sensor failure removes the reading and raises uncertainty',()=>{
  const c=E.config({...E.presets.sensor}),s=E.initial(c);s.t=23;assert.ok(E.observe(s,c).ids.includes(6));s.t=24;const obs=E.observe(s,c);assert.ok(!obs.ids.includes(6));assert.ok(obs.uncertainty[6]>1);
});
test('A cold-side temperature above the heat source cannot generate electricity',()=>{
  const c=E.config({outside:47}),control={supply:22,fan:.7,mode:'dry'},loads=Array(12).fill(.6);
  const p=E.coolingPower(loads,control,47),r=E.recovery(p,loads,control,47,c);assert.ok(r.hot<r.cold);near(r.harvest,0);
});
test('No heat consumer means no delivered heat or recovery pump consumption',()=>{
  const c=E.config({heatDemand:0}),control={supply:22,fan:.7,mode:'dry'},loads=Array(12).fill(.8),p=E.coolingPower(loads,control,30),r=E.recovery(p,loads,control,30,c);near(r.useful,0);near(r.pump,0);
});
test('Every default scenario completes the same mandatory work and batch jobs',()=>{
  const reports=[];
  for(const [key,preset] of Object.entries(E.presets)){
    const c=E.config(preset),runs={};
    for(const ctrl of ['reactive','physics','thermos']){
      const s=E.run(c,ctrl,M),q=E.summary(s,c);runs[ctrl]=q;
      assert.equal(s.t,72);assert.equal(s.trace.length,72);near(q.batch_completed_rack_minutes,360,1e-5);near(q.batch_remaining_rack_minutes,0,1e-5);assert.equal(q.missed_deadlines,0);
      // Electrical ledger: never subtract useful thermal heat or external avoided electricity.
      near(q.grid_kwh,q.it_kwh+q.cooling_kwh+q.monitoring_kwh+q.migration_kwh+q.recovery_aux_kwh-q.monitoring_covered_kwh,1e-6);
      near(q.recovered_electricity_kwh,q.monitoring_covered_kwh+q.storage_final_kwh,1e-6);
      assert.ok(q.monitoring_covered_kwh<=q.monitoring_kwh+1e-7);
      assert.ok(q.water_l>=0&&q.grid_kwh>0&&q.peak_inlet_c<50);
      for(const r of s.trace){r.temps.forEach(v=>assert.ok(Number.isFinite(v)));r.loads.forEach(v=>assert.ok(v>=0&&v<=1+1e-7));near(r.unserved,0,1e-5);}
    }
    near(runs.thermos.mandatory_rack_minutes,runs.reactive.mandatory_rack_minutes);
    near(runs.physics.mandatory_rack_minutes,runs.reactive.mandatory_rack_minutes);
    reports.push({scenario:key,results:runs});
  }
  fs.writeFileSync(path.join(__dirname,'../data/verified_benchmark.json'),JSON.stringify({data:'SIMULATED',version:E.VERSION,model_metrics:M.metadata.metrics,runs:reports},null,2));
});
test('One hundred percent sensors still use finite safety margins',()=>{
  const c=E.config({sensors:12}),s=E.initial(c);E.tick(s,c,'thermos',M);assert.equal(s.lastPlan.sensors.length,12);s.lastPlan.upper.forEach(v=>assert.ok(Number.isFinite(v)));
});
test('Stressed custom inputs disclose violations instead of hiding them',()=>{
  const c=E.config({outside:47,demand:90,restriction:.4,sensors:4,water:0,limit:28}),s=E.run(c,'thermos',M);
  assert.ok(s.violationRackMinutes>0);assert.ok(s.trace.some(r=>r.reasons.some(x=>x.includes('Escalate'))));near(s.water,0);
});
test('Model evidence is genuinely held out and beats persistence in its test environment',()=>{
  const m=M.metadata.metrics;assert.equal(m.train_episodes,120);assert.equal(m.calibration_episodes,30);assert.equal(m.test_episodes,30);assert.ok(m.mae_c<m.persistence_mae_c);assert.ok(m.test_95_interval_coverage>.90&&m.test_95_interval_coverage<=1);
});
