/* DOM-adapter smoke checks. These exercise UI code, not browser layout/rendering. */
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const ROOT=path.join(__dirname,'..');
class Element{
  constructor(attrs={}){this.attrs=attrs;this.id=attrs.id;this.dataset={};for(const [k,v]of Object.entries(attrs))if(k.startsWith('data-'))this.dataset[k.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=v;this.classes=new Set((attrs.class||'').split(' '));this.classList={toggle:(c,force)=>{const set=force===undefined?!this.classes.has(c):force;if(set)this.classes.add(c);else this.classes.delete(c);},remove:c=>this.classes.delete(c)};this.listeners={};this.value='';this.checked='checked'in attrs;this.hidden='hidden'in attrs;this.disabled='disabled'in attrs;this._html='';this.textContent='';}
  set innerHTML(v){this._html=v;}
  get innerHTML(){return this._html;}
  addEventListener(name,fn){(this.listeners[name]??=[]).push(fn);}
  async fire(name){for(const fn of this.listeners[name]||[])await fn({preventDefault(){}});}
  setAttribute(name,value){this.attrs[name]=value;}
  querySelectorAll(selector){if(selector!=='button')return[];return [...this._html.matchAll(/<button\b([^>]*)>/g)].map(m=>new Element(attrs(m[1])));}
  append(){} remove(){} click(){return this.fire('click');}
  insertAdjacentHTML(_,value){this._html+=value;}
}
function attrs(source){const result={};for(const m of source.matchAll(/([\w-]+)(?:="([^"]*)")?/g))result[m[1]]=m[2]??'';return result;}
function setup(){
  const html=fs.readFileSync(path.join(ROOT,'index.html'),'utf8'),elements=[],byId={};
  for(const m of html.matchAll(/<[a-z][a-z0-9]*\b([^>]*)>/gi)){const a=attrs(m[1]);if(a.id||a.class||a['data-chart']||a['data-page']){let el=new Element(a);elements.push(el);if(el.id)byId[el.id]=el;}}
  const downloads=[];
  const document={getElementById:id=>{assert.ok(byId[id],'Missing HTML ID: '+id);return byId[id];},querySelectorAll:s=>s==='[data-chart]'?elements.filter(e=>'chart'in e.dataset):elements.filter(e=>e.classes.has(s.slice(1))),createElement:()=>new Element(),body:new Element()};
  const window={Thermos:require('../assets/engine.js'),THERMOS_MODEL:require('../assets/model.js'),scrollTo(){}};
  const context={window,document,setTimeout,clearTimeout,console,Blob,URL:{createObjectURL:b=>{downloads.push(b);return'test:download';},revokeObjectURL(){}}};
  vm.runInNewContext(fs.readFileSync(path.join(ROOT,'assets/app.js'),'utf8'),context,{filename:'app.js'});
  return {byId,elements,downloads};
}
test('Dashboard boot, stepping, custom controls, history, reset and export work through UI handlers',async()=>{
  const {byId:d,downloads}=setup();
  assert.equal((d.racks.innerHTML.match(/data-rack=/g)||[]).length,12);assert.equal(d.clock.textContent,'09:00');
  assert.ok(d['model-metrics'].innerHTML.includes('0.143'));
  await d.step.fire('click');assert.equal(d.clock.textContent,'09:05');assert.ok(d.reasons.innerHTML.includes('cooling'));assert.ok(d['comparison-table'].innerHTML.includes('THERMOS'));
  await d.run.fire('click');assert.equal(d.clock.textContent,'15:00');assert.ok(d['run-status'].textContent.includes('complete'));
  d.scrub.value='0';await d.scrub.fire('input');assert.equal(d.clock.textContent,'09:00');assert.ok(d.kpis.innerHTML.includes('0.0<small>kWh'));
  d.scrub.value='24';await d.scrub.fire('input');assert.equal(d.clock.textContent,'11:00');
  await d.export.fire('click');assert.equal(downloads.length,1);const payload=JSON.parse(await downloads[0].text());assert.equal(payload.results.thermos.trace.length,72);assert.equal(payload.data,'SIMULATED');
  d.water.value='0';d.limit.value='28';await d.parameters.fire('submit');assert.equal(d.clock.textContent,'09:00');await d.step.fire('click');assert.ok(d.kpis.innerHTML.includes('0 L budget'));
  d.scenario.value='sensor';await d.scenario.fire('change');assert.equal(d.clock.textContent,'09:00');assert.equal(Number(d.sensors.value),6);assert.equal(d.failure.checked,true);
  await d['view-reactive'].fire('click');await d.step.fire('click');assert.ok(d.reasons.innerHTML.includes('baseline reacts'));
  d.truth.checked=true;await d.truth.fire('change');assert.ok(d.racks.innerHTML.includes('TRUTH'));
  await d.reset.fire('click');assert.equal(d.clock.textContent,'09:00');
});
test('Evidence-suite button computes 15 runs and exports the calculated results',async()=>{
  const {byId:d,downloads}=setup();await d.benchmark.fire('click');assert.ok(d['benchmark-status'].textContent.includes('15 runs'));assert.equal(d['export-suite'].disabled,false);
  await d['export-suite'].fire('click');const result=JSON.parse(await downloads[0].text());assert.equal(result.runs.length,15);assert.ok(result.runs.some(r=>r.controller==='physics'));
});
