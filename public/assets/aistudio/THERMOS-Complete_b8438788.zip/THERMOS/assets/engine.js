/* THERMOS educational simulator. No browser or third-party runtime required. */
(function(root){
'use strict';
const N=12, DT=5, STEPS=72, HORIZON=3, VERSION='1.0.0';
const clip=(x,a,b)=>Math.max(a,Math.min(b,x));
const sum=a=>a.reduce((s,v)=>s+v,0), mean=a=>sum(a)/a.length;
const clone=x=>JSON.parse(JSON.stringify(x));
function rng(seed){let s=seed>>>0;return()=>{s=(Math.imul(1664525,s)+1013904223)>>>0;return s/4294967296;};}
const presets={
  normal:{label:'A normal working day',outside:32,demand:64,water:140,sensors:8,restriction:.12,heatDemand:8,heatwave:false,failure:false,seed:42},
  heatwave:{label:'Heatwave + workload surge',outside:43,demand:83,water:140,sensors:8,restriction:.30,heatDemand:8,heatwave:true,failure:false,seed:42},
  water:{label:'Water restriction',outside:41,demand:78,water:20,sensors:8,restriction:.25,heatDemand:8,heatwave:true,failure:false,seed:42},
  sensor:{label:'A sensor goes offline',outside:40,demand:79,water:100,sensors:6,restriction:.30,heatDemand:8,heatwave:true,failure:true,seed:42},
  noheat:{label:'No customer for recovered heat',outside:36,demand:72,water:100,sensors:8,restriction:.18,heatDemand:0,heatwave:false,failure:false,seed:42}
};
const sensorOrder=[6,1,10,3,8,5,0,11,2,7,4,9];
function config(input={}){return Object.assign({limit:30,priority:'balanced',recovery:true},presets.heatwave,input);}
function adjacent(i){let r=Math.floor(i/4),c=i%4,a=[];for(let j=0;j<N;j++)if(Math.abs(Math.floor(j/4)-r)+Math.abs(j%4-c)===1)a.push(j);return a;}
function neighbor(load,i){return mean(adjacent(i).map(j=>load[j]));}
function restriction(c,i){return c.restriction*(i===6?1:i===7?.55:.10);}
function ambient(c,t){return c.outside+2*Math.sin(Math.PI*t/STEPS)+(c.heatwave?1.4*Math.exp(-Math.pow((t-37)/14,2)):0);}
function rawDemand(c,t){
  const peak=c.heatwave?1+ .18*Math.exp(-Math.pow((t-36)/12,2)):1;
  return Array.from({length:N},(_,i)=>clip(c.demand/100*peak*(.77+.18*Math.sin(t*.07+i*1.5)+(i===6?.22:0)),.10,.97));
}
function targetTemperature(temp,load,near,supply,fan,outside,block){
  const delivery=Math.max(.22,.48+.83*fan-Math.max(0,outside-35)*.012-block);
  const target=supply+(3.5*load+1.2*near+.6)/delivery;
  return temp+(target-temp)*(1-Math.exp(-DT/12));
}
function features(temp,load,near,control,outside,block){return[temp,load,near,control.supply,control.fan,outside,block];}
function forestPredict(model,x){
  let total=0;for(const tree of model.trees){let i=0;while(tree[i][0]>=0){const n=tree[i];i=x[n[0]]<=n[1]?n[2]:n[3];}total+=tree[i][4];}return total/model.trees.length+(model.metadata.target==='delta_temperature'?x[0]:0);
}
function forecast(temps,loads,control,outside,c,model){
  return temps.map((temp,i)=>{
    const near=neighbor(loads,i),block=restriction(c,i);
    if(model)return forestPredict(model,features(temp,loads[i],near,control,outside,block));
    for(let k=0;k<HORIZON;k++)temp=targetTemperature(temp,loads[i],near,control.supply,control.fan,outside,block);
    return temp;
  });
}
function physics(temps,loads,control,outside,c){return temps.map((v,i)=>targetTemperature(v,loads[i],neighbor(loads,i),control.supply,control.fan,outside,restriction(c,i)));}
function sensorMask(c,t){const ids=sensorOrder.slice(0,c.sensors);return ids.filter(i=>!(c.failure&&t>=24&&i===6));}
function observe(state,c){
  const ids=sensorMask(c,state.t),expected=state.expected;
  const readings={};for(const i of ids)readings[i]=state.temps[i]+.08*Math.sin(i+state.t*.37);
  const estimated=Array.from({length:N},(_,i)=>{
    if(ids.includes(i))return readings[i];
    let weight=0,bias=0;for(const j of ids){const dist=Math.abs(i%4-j%4)+Math.abs(Math.floor(i/4)-Math.floor(j/4));const w=1/(1+dist*dist);bias+=(readings[j]-expected[j])*w;weight+=w;}
    return expected[i]+(weight?bias/weight:0);
  });
  const uncertainty=estimated.map((_,i)=>ids.includes(i)?.12:.75+(c.failure&&i===6?.45:0));
  return{estimated,uncertainty,ids,readings};
}
function balanceLoads(raw,extra,style){
  // 45% is pinned; only the remainder can move. Batch work is always eligible.
  const pinned=raw.map(v=>v*.45),loads=pinned.slice();let movable=sum(raw)*.55+extra;
  if(style==='original'){
    for(let i=0;i<N;i++){const add=Math.min(1-loads[i],raw[i]*.55);loads[i]+=add;movable-=add;}
  }
  const order=Array.from({length:N},(_,i)=>i);
  // Both options conserve work; spread fills the coolest/lightest available bins.
  if(style==='consolidate')order.sort((a,b)=>pinned[b]-pinned[a]);
  let iterations=0;
  while(movable>1e-8&&iterations++<2000){
    let i=style==='consolidate'?order.find(j=>loads[j]<1-1e-8):order.reduce((a,j)=>loads[j]<loads[a]?j:a,0);
    if(i===undefined||loads[i]>=1-1e-8)break;
    let add=Math.min(style==='consolidate'?1:.025,1-loads[i],movable);loads[i]+=add;movable-=add;
  }
  const moved=.5*sum(loads.map((v,i)=>Math.abs(v-raw[i])));return{loads,moved,unserved:Math.max(0,movable)};
}
function releaseJobs(state){
  const specs=[{id:'J1',release:6,due:30,work:100},{id:'J2',release:24,due:54,work:150},{id:'J3',release:42,due:72,work:110}];
  for(const j of specs)if(j.release===state.t)state.jobs.push({...j,remaining:j.work,late:false});
}
function batchNeeded(state,raw,fraction){
  const open=state.jobs.filter(j=>j.remaining>1e-7),backlog=sum(open.map(j=>j.remaining));
  const available=Math.max(0,N-sum(raw));
  let urgent=0;for(const j of open)urgent+=j.remaining/(DT*Math.max(1,j.due-state.t));
  // Reserve a 10-minute deadline margin; controller may defer the optional excess.
  const dueSoon=open.some(j=>j.due-state.t<=3);
  return Math.min(available,backlog/DT,Math.max(dueSoon?Math.min(available,backlog/DT):urgent,2*fraction));
}
function coolingPower(loads,control,outside){
  const it=sum(loads.map(l=>.24+3*l));
  const dryCOP=clip(4.4-.065*(outside-25)+.10*(control.supply-20),1.4,6);
  const cop=dryCOP+(control.mode==='wet'?1.15:0);
  const fan=.35+4.2*Math.pow(control.fan,3),chiller=(it+fan)/cop;
  const water=control.mode==='wet'?(it+fan+chiller)*.95:0; // litres/hour; all site water is this model's evaporative makeup.
  return{it,fan,chiller,cooling:fan+chiller,water,cop};
}
function recovery(power,loads,control,outside,c){
  // Illustrative compatible liquid loop; heat and electricity are separate ledgers.
  const hot=32+12*mean(loads)+.4*(control.supply-20),cold=outside;
  const heatAvailable=power.it*.55,tegHeat=heatAvailable*.03;
  const carnot=Math.max(0,1-(cold+273.15)/(hot+273.15));
  const gross=tegHeat*carnot*.12*.85; // 12% of Carnot; then 85% power conditioning.
  const tegAux=.0007,net=Math.max(0,gross-tegAux);
  const possible=hot>=38?Math.min(Math.max(0,heatAvailable-tegHeat),c.heatDemand):0;
  const pump=possible>0?.08+.012*possible:0;
  // Reject thermal reuse when its pump uses more electricity than a COP=2.5 recipient saves.
  const useful=c.recovery&&possible/2.5>pump?possible:0;
  return{hot,cold,heatAvailable,tegHeat,gross:c.recovery?gross:0,harvest:c.recovery?net:0,useful,pump:useful?pump:0,tegAux:c.recovery&&gross>tegAux?tegAux:0,avoidedExternal:useful/2.5};
}
function initial(c){return{t:0,temps:Array(N).fill(26),expected:Array(N).fill(26),jobs:[],control:{supply:22,fan:.7,mode:'dry'},water:0,energy:0,itEnergy:0,coolingEnergy:0,monitorEnergy:0,recoveryEnergy:0,generated:0,usedHarvest:0,stored:0,heat:0,externalAvoided:0,completed:0,mandatory:0,missed:0,violationRackMinutes:0,peak:26,migrationEnergy:0,logs:[],trace:[],lastPlan:null};}
function candidateCost(action,state,c,raw,outside,obs,model,useAI){
  const extra=batchNeeded(state,raw,action.fraction),layout=balanceLoads(raw,extra,action.style);
  const power=coolingPower(layout.loads,action,outside);
  const predictions=forecast(obs.estimated,layout.loads,action,outside,c,useAI?model:null);
  const futureRaw=rawDemand(c,Math.min(STEPS-1,state.t+HORIZON));
  const futureLayout=balanceLoads(futureRaw,batchNeeded(state,futureRaw,action.fraction),action.style);
  const future=forecast(obs.estimated,futureLayout.loads,action,ambient(c,Math.min(STEPS-1,state.t+HORIZON)),c,useAI?model:null);
  const margin=useAI&&model?model.metadata.calibration_q95:.15;
  const upper=predictions.map((v,i)=>Math.max(v,future[i])+margin+obs.uncertainty[i]);
  const risk=Math.max(...upper)-c.limit;
  const waterNext=power.water*DT/60;
  // Allocate the remaining water over remaining time; permit exceptional safety overrides explicitly.
  const waterAllowance=Math.max(0,c.water-state.water)/Math.max(1,STEPS-state.t)*1.12;
  const waterExcess=Math.max(0,waterNext-waterAllowance);
  const overdue=state.jobs.filter(j=>j.remaining>1e-6&&j.due<=state.t+3);
  const missPenalty=overdue.length&&extra<Math.min(2,sum(overdue.map(j=>j.remaining))/DT)?1000:0;
  const mig=.018*layout.moved;
  const waterWeight=c.priority==='water'?1.25:c.priority==='energy'?.02:.14;
  const switchPenalty=.05*Math.abs(action.supply-state.control.supply)+.1*Math.abs(action.fan-state.control.fan);
  const score=power.cooling+power.it+mig*60/DT +waterWeight*power.water+waterExcess*100+Math.max(0,risk)*2000+missPenalty+switchPenalty;
  return{...action,layout,extra,power,predictions,upper,risk,waterExcess,score};
}
function selectAction(state,c,obs,model,controller){
  const raw=rawDemand(c,state.t),outside=ambient(c,state.t);
  if(controller==='reactive'){
    const measured=Math.max(...Object.values(obs.readings));
    let control={...state.control,fraction:1,style:'original'};
    if(state.t===0)control={...control,supply:22,fan:.7};
    if(measured>c.limit-.45){control.supply=20;control.fan=1;}
    else if(measured<c.limit-2){control.supply=24;control.fan=.45;}
    else {control.supply=22;control.fan=.7;}
    // Conventional controller enables evaporative assistance at high ambient temperature when budget remains.
    const probe=coolingPower(raw,{...control,mode:'wet'},outside);
    control.mode=outside>35&&state.water+probe.water*DT/60<=c.water?'wet':'dry';
    return candidateCost(control,state,c,raw,outside,obs,model,false);
  }
  let choices=[];
  for(const supply of [20,22,24])for(const fan of [.45,.7,1])for(const mode of ['dry','wet'])for(const fraction of [0,1])for(const style of ['original','spread']){
    choices.push(candidateCost({supply,fan,mode,fraction,style},state,c,raw,outside,obs,model,controller==='thermos'));
  }
  choices.sort((a,b)=>a.score-b.score);const best=choices[0];
  best.alternatives=[choices.find(x=>x.mode!==best.mode),choices.find(x=>x.style!==best.style),choices.find(x=>x.fraction!==best.fraction)].filter(Boolean);
  return best;
}
function explain(plan,state,c,obs){
  const reasons=[];
  if(plan.style==='spread')reasons.push('Redistribute eligible work; pinned work stays on its original rack.');
  else reasons.push('Keep the original workload placement; a move did not improve this decision score.');
  if(plan.extra>0)reasons.push('Run '+plan.extra.toFixed(2)+' rack-equivalents of batch work while protecting deadlines.');
  else if(state.jobs.some(j=>j.remaining>0))reasons.push('Defer flexible batch work; no immediate deadline requires it to run.');
  reasons.push('Use '+plan.mode+' cooling at '+plan.supply+'°C supply and '+Math.round(plan.fan*100)+'% airflow.');
  if(obs.ids.length<N)reasons.push((N-obs.ids.length)+' rack temperatures are estimated; uncertainty is added to the safety margin.');
  if(plan.risk>0)reasons.push('No tested action meets the conservative forecast limit. Escalate to the operator; safety is not guaranteed.');
  if(plan.waterExcess>.01)reasons.push('This action exceeds the remaining water allocation to reduce thermal risk.');
  return reasons;
}
function tick(state,c,controller,model){
  if(state.t>=STEPS)return state;
  releaseJobs(state);const obs=observe(state,c),plan=selectAction(state,c,obs,model,controller),outside=ambient(c,state.t);
  const prev=state.temps.slice();state.temps=physics(state.temps,plan.layout.loads,plan,outside,c);
  state.expected=physics(obs.estimated,plan.layout.loads,plan,outside,c);
  const p=plan.power,rec=recovery(p,plan.layout.loads,plan,outside,c),hours=DT/60;
  const monitor=controller==='thermos'?.055:.020;
  const produced=rec.harvest*hours,need=monitor*hours;
  const available=state.stored+produced,used=Math.min(available,need);
  state.stored=Math.min(.05,Math.max(0,available-used));
  // usable harvest already subtracts harvester electronics; don't debit it twice.
  const migration=.018*plan.layout.moved;
  const draw=(p.it+p.cooling+monitor+rec.pump)*hours+migration-used;
  state.energy+=draw;state.itEnergy+=p.it*hours;state.coolingEnergy+=p.cooling*hours;
  state.monitorEnergy+=monitor*hours;state.recoveryEnergy+=rec.pump*hours;
  state.generated+=produced;state.usedHarvest+=used;state.water+=p.water*hours;
  state.heat+=rec.useful*hours;state.externalAvoided+=rec.avoidedExternal*hours;
  state.migrationEnergy+=migration;
  let work=plan.extra*DT;for(const job of state.jobs.slice().sort((a,b)=>a.due-b.due)){const done=Math.min(job.remaining,work);job.remaining-=done;work-=done;state.completed+=done;}
  for(const job of state.jobs)if(!job.late&&state.t+1>=job.due&&job.remaining>1e-5){job.late=true;state.missed++;}
  const raw=rawDemand(c,state.t);state.mandatory+=sum(raw)*DT;
  // Endpoint count per 5-minute step, not a claimed continuous-time measurement.
  const violations=state.temps.filter(v=>v>c.limit).length;
  state.violationRackMinutes+=violations*DT;state.peak=Math.max(state.peak,...state.temps);
  const record={step:state.t,minute:(state.t+1)*DT,outside,temps:state.temps.slice(),estimated:obs.estimated,uncertainty:obs.uncertainty,sensors:obs.ids,loads:plan.layout.loads.slice(),predictions:plan.predictions,upper:plan.upper,control:{supply:plan.supply,fan:plan.fan,mode:plan.mode},style:plan.style,batch:plan.extra,energy:state.energy,water:state.water,heat:state.heat,generated:state.generated,stored:state.stored,monitorEnergy:state.monitorEnergy,usedHarvest:state.usedHarvest,peak:Math.max(...state.temps),gridKW:draw/hours,coolingKW:p.cooling,rec,violations,backlog:sum(state.jobs.map(j=>j.remaining)),deadlineMisses:state.missed,reasons:explain(plan,state,c,obs),alternatives:(plan.alternatives||[]).map(x=>({supply:x.supply,fan:x.fan,mode:x.mode,style:x.style,batch:x.extra,predictedMax:Math.max(...x.upper),score:x.score,waterExcess:x.waterExcess})),score:plan.score,unserved:plan.layout.unserved};
  record.totals=summary({...state,t:state.t+1},c);
  if(!state.logs.length||state.t%6===0||violations||c.failure&&state.t===24)state.logs.push({minute:record.minute,text:record.reasons.join(' ')});
  state.control={supply:plan.supply,fan:plan.fan,mode:plan.mode};state.lastPlan=record;state.trace.push(record);state.t++;
  return state;
}
function run(c,controller,model){const s=initial(c);while(s.t<STEPS)tick(s,c,controller,model);return s;}
function summary(state,c){return{controller:state.controller||'',minutes:state.t*DT,grid_kwh:state.energy,cooling_kwh:state.coolingEnergy,it_kwh:state.itEnergy,monitoring_kwh:state.monitorEnergy,migration_kwh:state.migrationEnergy,recovery_aux_kwh:state.recoveryEnergy,water_l:state.water,water_budget_l:c.water,water_budget_exceeded:state.water>c.water+1e-6,peak_inlet_c:state.peak,over_limit_rack_minutes:state.violationRackMinutes,mandatory_rack_minutes:state.mandatory,batch_completed_rack_minutes:state.completed,batch_remaining_rack_minutes:sum(state.jobs.map(j=>j.remaining)),missed_deadlines:state.missed,useful_heat_kwh_th:state.heat,recovered_electricity_kwh:state.generated,monitoring_covered_kwh:state.usedHarvest,monitoring_coverage_pct:state.monitorEnergy?100*state.usedHarvest/state.monitorEnergy:0,storage_initial_kwh:0,storage_final_kwh:state.stored,external_heat_user_avoided_kwh:state.externalAvoided};}
const api={VERSION,N,DT,STEPS,HORIZON,clip,sum,mean,clone,rng,presets,config,adjacent,neighbor,restriction,ambient,rawDemand,targetTemperature,features,forestPredict,forecast,physics,sensorMask,observe,balanceLoads,coolingPower,recovery,initial,tick,run,summary};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.Thermos=api;
})(typeof globalThis!=='undefined'?globalThis:this);
