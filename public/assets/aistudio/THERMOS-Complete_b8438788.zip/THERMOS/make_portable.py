"""Build a single offline HTML from the canonical local assets. Standard library only."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
html=(ROOT/'index.html').read_text()
style=(ROOT/'assets/style.css').read_text()
html=html.replace('<link rel="stylesheet" href="assets/style.css">','<style>\n'+style+'\n</style>')
for name in ['model','engine','app']:
    source=(ROOT/f'assets/{name}.js').read_text().replace('</script','<\\/script')
    # defer has no effect on inline classic scripts. Put them at the end of the body instead.
    html=html.replace(f'<script defer src="assets/{name}.js"></script>','')
    html=html.replace('</body>',f'<script>\n{source}\n</script>\n</body>')
dest=ROOT/'THERMOS-Open-in-Browser.html'
dest.write_text(html)
print(f'Built {dest.name} ({dest.stat().st_size:,} bytes). Open it directly in a browser.')
