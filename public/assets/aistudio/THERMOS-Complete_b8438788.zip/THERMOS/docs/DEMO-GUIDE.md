# Eight-minute demonstration and rehearsal guide

## Before the judges arrive

Open `index.html` on the actual demonstration laptop. Turn Wi-Fi off for a rehearsal. Keep the charger connected. Run the heatwave and sensor-loss scenarios once, inspect the evidence suite and practise restoring the initial state. Save an export and record a short screen video as a backup. The prototype runs offline; reference links require internet only if opened.

Two presenters can split responsibilities: Presenter 1 explains the operator's problem and the decisions; Presenter 2 operates the interface and explains the evidence and model. Both must understand the equations and be ready for questions.

## 0:00–1:00 — State the problem

“Data centres need to finish computing jobs safely, even when weather and demand change. Cooling decisions affect electricity and water. THERMOS is our digital prototype for comparing those decisions before acting.”

Say explicitly: “This is a simulated facility. We are demonstrating a working prediction and decision system; we are not claiming measured industrial savings.”

## 1:00–2:00 — Introduce the facility

Choose **Heatwave + workload surge**. Show the 12 racks. Explain solid versus hollow sensor dots, the configurable inlet-temperature limit and the R07 restriction. Click R07. Show the initially empty charts and explain that results are calculated during the demonstration.

## 2:00–4:30 — Show the complete decision

Use **+5 min** or **Play**. Read one prediction, then the selected supply, airflow and cooling mode. Explain whether work moved and how batch deadlines are protected. Expand **Why not another action?**

Press **Run full comparison**. Both strategies use the same incoming work and weather. Switch between the two rack views and graph tabs. Use the timeline slider to revisit an earlier decision.

Do not read every number. Point out the causal story: conditions → temperature forecast → candidate actions → chosen action → independently calculated outcome.

## 4:30–5:30 — Report the trade-off

Check completed batch work and deadlines first. Then check over-limit rack-minutes and resources. In the delivered default heatwave scenario, THERMOS conserves cooling water at the cost of a small electricity increase. Describe both. Do not say “saves energy and water” if that run does not show both.

The default water-restriction scenario may be a useful second result because it illustrates the interaction between constrained water, energy and safe workloads. Read the actual current results.

## 5:30–6:30 — Give the judge control

Invite the judge to select **A sensor goes offline**, or change water allowance through **Adjust conditions**. Press **Apply & reset** after changing inputs.

In the sensor-loss scenario, R07 loses its reading at 11:00. Explain the fallback estimate and extra safety margin. Run the full comparison, then use **Reveal simulator truth** to evaluate the controller's estimates. The toggle only changes the evaluator view.

## 6:30–7:15 — Explain the recovery ambition

Show useful thermal heat and recovered electricity separately. Explain the ambient cold sink. If electrical harvest is zero, explain why: the source does not have a sufficient temperature advantage. Monitoring still needs external power.

“The model tests how much monitoring can be powered from recovered electricity. We do not assume that waste heat can power the entire platform.”

## 7:15–8:00 — Explain the AI and next validation

Open **Model & science**. Point to the actual model: a trained Random Forest predicting a 15-minute temperature change. Identify held-out test error and the persistence comparison. State that all episodes are synthetic.

“Our next step is to calibrate the plant and test the predictor with independently collected real facility data and measured equipment curves.”

## Questions to rehearse

**Where is the AI?**

The 24-tree Random Forest maps seven thermal/workload inputs to a 15-minute temperature change. The action search and recovery calculations are separate algorithms. The sparse-sensor estimator uses a physical prior and spatial residual correction.

**How can you know whether it works?**

Separate whole episodes train, calibrate and test the predictor. Run outcomes come from the plant equations, not the forest's own predictions. The evidence suite compares equal work under identical conditions and retains failures.

**Could ordinary equations do this?**

Yes, in a simulator whose equations are perfectly known. That is why the engineering planner is included. ML's potential role in a real facility would be learning interactions that an imperfect engineering model misses; that benefit has not been established by these synthetic experiments.

**Why might THERMOS use more electricity?**

It can choose dry cooling to conserve water or higher airflow to protect temperatures, and it includes assumed AI overhead. Resource and safety objectives can compete.

**What if the AI is wrong?**

The forecast adds a calibrated empirical margin and extra uncertainty for unsensed racks. Actual violations remain visible. This is not a safety-certified industrial controller, and a real deployment needs independent safeguards.

**Are you creating free energy?**

No. Electrical generation is limited by source/sink temperature difference, conversion efficiency and supporting loads. Most waste heat remains heat. The model never increases workload merely to generate power.

**Why are there no physical racks or sensors?**

This is a digital model/prototype with implemented AI. It lets judges manipulate a complete operating scenario on a laptop. Real hardware validation is future work.

**What is original about your contribution?**

Our student prototype connects prediction, sparse sensing, workload choices, cooling resources and recovery accounting into an interactive, explainable experiment. We do not claim to have invented AI cooling or thermoelectric harvesting.

**What should not be claimed?**

No guaranteed prize, industrial savings, universal safe temperature, world-first invention, real autonomous control, physically generated electricity or complete self-powering. Demonstrate the implemented decision loop and defend the evidence you have.
