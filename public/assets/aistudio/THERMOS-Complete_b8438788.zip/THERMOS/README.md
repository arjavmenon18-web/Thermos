# THERMOS — Thermal Intelligence & Sustainable Operations

A complete offline digital prototype for the HOPE 2026 senior Green Data Center challenge.

**Fastest option:** download the companion `THERMOS-Open-in-Browser.html` file and double-click it. It contains the whole runnable interface and trained model in one file. The ZIP below also contains all source code, training scripts, documentation and tests.

## Run it: the easiest method (no installs)

1. Download `THERMOS-Complete.zip`.
2. **Extract the entire ZIP first.** On Windows, right-click → Extract All. On a Mac, double-click the ZIP.
3. Open the extracted `THERMOS` folder.
4. Double-click **`index.html`** (or the self-contained **`THERMOS-Open-in-Browser.html`**). It opens in your browser.
5. Select **Heatwave + workload surge**, then click **Run full comparison**.

Use a current desktop Chrome, Edge, Firefox or Safari browser. JavaScript must be enabled. The app uses local script files; keep the `assets` folder alongside `index.html`. Do not open the HTML from inside an unextracted ZIP or a cloud-drive preview.

There is no account, API key, paid service, Node.js, Python, Streamlit or internet requirement for the demonstration. This portable edition uses plain HTML/CSS/JavaScript with an exported, genuinely trained Random Forest. It does not use a chatbot or a remote API.

If a Mac refuses the optional `.command` launcher, open `index.html` directly. The optional launcher is only a convenience. `START-Windows.bat` does the same on Windows.

## Alternative: run through localhost

Use this if a managed browser blocks local-file scripts. Python 3.10+ is enough; **no pip installation is required**.

Mac / Linux, in Terminal:

```bash
cd /path/to/THERMOS
python3 serve.py
```

Windows, in Command Prompt:

```bat
cd C:\path\to\THERMOS
py serve.py
```

The launcher opens `http://127.0.0.1:8501`. Keep the terminal window open while using the app. Ctrl+C stops it. If port 8501 is busy, add `--port 8502`. This optional server binds only to your own computer, not your network. Python need only be installed for this alternative or for retraining.

## The first demonstration

1. Begin with **Heatwave + workload surge**. Both controllers start from the same state.
2. Click **+5 min** several times or **Play**. Filled sensor dots indicate measured values; hollow dots indicate estimates.
3. Select **R07** and explain its airflow restriction, predicted temperature and uncertainty.
4. Inspect **A plan, with reasons** and expand **Why not another action?**
5. Click **Run full comparison** to calculate the entire six-hour run.
6. Look at electricity, water, safety, batch completion and deadlines together. The default heatwave run trades a small electricity increase for lower cooling-water consumption. Do not describe it as an across-the-board saving.
7. Switch the chart between electricity, water and hottest-rack temperature. Switch the rack view between THERMOS and the reactive baseline.
8. Move the timeline slider to inspect earlier recorded decisions. At the far-left position, KPIs return to the initial state. Exports include the entire computed run, not just the selected point.
9. Choose **A sensor goes offline**, run again, and inspect the result after 11:00. R07 loses its reading. The controller uses an estimate plus extra uncertainty.
10. **Reveal simulator truth** is an evaluator tool. It does not give hidden temperatures to either controller.
11. Open **Adjust conditions** to change temperature, demand, water allowance, sensors, restriction, limit, priority and heat demand. Press **Apply & reset**, then run again.
12. **Export results** downloads a JSON file containing configuration, model metadata, both summaries, step-by-step truth/estimates/forecasts and decision logs.
13. Open **Evidence lab**, press **Run evidence suite**, then download the results. This runs five scenarios × three controllers using preset defaults, independently of your current custom settings.

`docs/DEMO-GUIDE.md` contains an eight-minute script and questions to rehearse. The same guide is available inside the application.

## What is implemented

- Twelve virtual racks with a reproducible thermal model and 5-minute time steps over six hours.
- Current and forecast weather profiles, mandatory computing demand and three flexible batch jobs.
- A real 24-tree Random Forest, trained in scikit-learn, exported as numeric trees and evaluated directly in the browser.
- A 15-minute temperature forecast with a separately calibrated empirical error margin.
- Sparse-sensor estimation using a physical prior and spatially weighted observed residuals.
- Sensor failure, workload redistribution, task deferral, dry/wet cooling and water-allocation decisions.
- A finite 72-action search respecting pinned workloads and including migration costs and deadline urgency.
- Reactive baseline and engineering-planner comparison. The engineering planner uses known equations instead of the learned predictor and is a useful ablation, not an inferior strawman.
- Separate electrical, water, useful-heat, harvester and monitoring/storage ledgers.
- Timeline playback, history inspection, scenario controls, explanations, charts, exports and an evidence suite.
- No network calls, remote fonts, third-party CDNs or telemetry. External reference links only open if you click them.

## Interpret results correctly

All operating data is synthetic. Every outcome describes this simplified simulator, not a validated production facility. The model learns the simulator's behaviour; real-facility data would be needed to establish transfer to real operations. The included benchmark contains both positive results and trade-offs.

Thermal safety refers to **rack inlet air**, not CPU temperature. The default 30°C limit is a configurable demonstration constraint, not a universal equipment standard. A weighted finite-action search may fail a limit, miss a deadline under stress, or override its water allocation. Those events must remain visible.

Workload units are rack-load-minutes. Three jobs contain 100, 150 and 110 units, for 360 total. Completion and deadlines must be checked before claiming resource improvements. Mandatory work is identical for every controller. Forty-five percent of each rack's mandatory load is pinned; the rest can move. Migration electricity is charged per action; stateful application dependencies and real network latency are not modelled.

The AI's forecast freezes candidate loads/controls/ambient for 15 minutes. The planner also checks a short-term future workload and weather estimate. This is a short-horizon demonstration, not a validated 48-hour rack forecast.

## Heat recovery and self-powering

The recovery panel is a **feasibility calculation**, not a hardware demonstration. Its liquid-loop capture fraction, temperatures, TEG performance and auxiliary loads are explicit assumptions. The heat recipient is modelled as a nearby 35°C preheat demand needing at least 38°C source temperature.

Useful thermal output (`kWh_th`) is kept separate from recovered electricity (`Wh` / `kWh`). Thermal reuse never directly reduces the application's grid-electricity total. It may displace heat production elsewhere; that separate illustrative offset assumes a recipient heat-pump COP of 2.5.

The TEG uses outdoor ambient as the cold sink. In a heatwave, the model may have no usable temperature difference and therefore **zero generated electricity**. Usable harvest is after power conditioning and harvester electronics. It powers monitoring first; the 50 Wh storage starts empty. There is no assumed full self-sufficiency. Artificially keeping a server hotter to generate power is not an allowed action.

Full equations, boundaries, resource scoring and limitations are in `docs/SCIENCE.md` and inside **Model & science**.

## Reproduce training (optional; not needed to run)

Requires Python 3.10+ and Node.js 18+; tested here with Python 3.12, Node 24 and scikit-learn 1.8. Create an isolated environment first.

Mac / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-training.txt
python training/train.py
```

Windows:

```bat
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements-training.txt
python training/train.py
```

Node runs the public thermal engine to generate 180 independent episodes (51,840 rows). Episodes 0–119 train the forest; 120–149 calibrate its residual margin; 150–179 are held out for final testing. A fixed seed makes the dataset reproducible. Different compatible library versions may yield slightly different model results.

Training replaces `assets/model.js`, `data/model_metrics.json`, `data/inference_reference.json` and `data/training_sample.csv`. Refresh the browser afterward. The delivered model is ready to use; no downloaded pickle or model runtime is needed.

After editing or retraining, run `python make_portable.py` to refresh the optional single-file edition. The multi-file `index.html` always reads the current assets directly.

## Run verification (optional)

```bash
node --test tests/engine.test.js
node --test tests/ui-smoke.test.js
```

This checks Python/JavaScript prediction parity, workload conservation, sensor isolation, recovery behaviour, electrical ledgers, default workload/deadline completion and stressed-case disclosure. It writes `data/verified_benchmark.json` from the actual test runs. `data/QA-REPORT.md` records the delivered version's checks.

## Project files

| File | Purpose |
|---|---|
| `index.html` | Open this to run the complete application |
| `THERMOS-Open-in-Browser.html` | Self-contained runnable edition |
| `make_portable.py` | Rebuild the single-file edition after edits |
| `assets/style.css` | Responsive interface styling |
| `assets/app.js` | Dashboard, controls, charts, playback and exports |
| `assets/engine.js` | Simulation, estimation, action search and ledgers |
| `assets/model.js` | Exported numeric trained forest |
| `training/generate_data.js` | Reproducible synthetic data generation |
| `training/train.py` | Training, calibration, evaluation and export |
| `data/model_metrics.json` | Actual held-out evaluation metrics |
| `data/training_sample.csv` | Inspectable sample of the generated data |
| `data/inference_reference.json` | Python reference predictions for parity tests |
| `data/verified_benchmark.json` | Calculated benchmark for the delivered version |
| `tests/engine.test.js` | Scientific and accounting verification |
| `serve.py` | Optional standard-library localhost launcher |
| `docs/DEMO-GUIDE.md` | Competition demonstration and Q&A preparation |
| `docs/SCIENCE.md` | Equations, units, scoring and limitations |

## Troubleshooting

- **Blank or unstyled page:** extract the whole ZIP, keep the assets folder intact, then reopen index.html. Use the optional Python launcher if local scripts are blocked by school policy.
- **Pressing Run seems busy:** allow it to finish. The app is evaluating candidate actions and generating actual results. A modern laptop is recommended. Play is intentionally slower for explanation.
- **A control will not work:** pause playback or wait for the current full run/evidence suite to complete. Parameter changes are applied only with Apply & reset.
- **Numbers are different after editing:** resource priority, safety limit, sensor count, water budget and workload alter the result. Export the exact configuration for reproducibility.
- **Internet unavailable:** the app does not need it. Links to research and optional first-time Python package installation do need internet.
- **No stored energy or self-powering:** zero is a valid result. Under the included heat and cold-sink assumptions, harvest is often tiny or absent.

## Before the competition

Run the app on the actual laptop, rehearse the eight-minute guide, test it with Wi-Fi off, save a results export and record a short screen video as a backup. The eight-minute guide is a recommendation; use the organiser's final instructions for event requirements.
