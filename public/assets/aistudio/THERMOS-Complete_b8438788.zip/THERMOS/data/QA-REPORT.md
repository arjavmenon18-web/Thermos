# THERMOS delivery verification

Verified on 21 October 2026.

## Checks completed

- JavaScript syntax checks for the simulation engine, interface and exported model.
- Ten engine/model verification tests passed, including reference prediction parity, workload conservation, no hidden-temperature leakage, sensor failure, recovery boundary behaviour and electricity accounting.
- Five default scenarios × three controllers were run. Each completed all 360 rack-load-minutes of batch work, with zero missed deadlines. Resource and thermal outcomes vary and are retained in `verified_benchmark.json`.
- A deliberately stressed custom scenario produced visible thermal violations and escalation messages, verifying that the prototype does not hide failures.
- Two UI-handler smoke tests passed through a DOM adapter: startup, stepping, full run, history scrubbing, custom conditions, scenario changes, baseline selection, truth reveal, reset, run export, the 15-run evidence suite and evidence export.
- Training/test separation uses complete episodes; the exported numeric forest matches scikit-learn reference predictions within 0.00001°C.

## Actual held-out synthetic model results

| Measure | Result |
|---|---:|
| Training samples | 34,560 |
| Calibration samples | 8,640 |
| Test samples | 8,640 |
| Test mean absolute error | 0.1431°C |
| Test RMSE | 0.2019°C |
| Persistence predictor MAE | 1.2339°C |
| Empirical calibrated interval coverage on test episodes | 95.71% |

These numbers describe independent synthetic episodes from the same simplified simulator, not real equipment accuracy.

## Default six-hour outcomes

| Scenario | Controller | Grid kWh | Cooling water L | Over-limit rack-minutes |
|---|---|---:|---:|---:|
| Normal | Reactive | 188.38 | 0.00 | 0 |
| Normal | THERMOS | 185.46 | 0.00 | 0 |
| Heatwave | Reactive | 246.15 | 139.83 | 0 |
| Heatwave | THERMOS | 252.16 | 0.00 | 0 |
| Water restriction | Reactive | 239.14 | 18.50 | 0 |
| Water restriction | THERMOS | 235.90 | 0.00 | 0 |
| Sensor failure | Reactive | 232.90 | 98.84 | 220 |
| Sensor failure | THERMOS | 240.20 | 0.00 | 0 |
| No heat consumer | Reactive | 203.76 | 99.35 | 0 |
| No heat consumer | THERMOS | 205.42 | 0.00 | 0 |

No claim of unconditional resource improvement is justified. The engineering planner results are also available in the benchmark JSON and the application's Evidence lab.

## Verification limits

No real-browser visual inspection was available in this build environment. UI handlers were exercised programmatically; CSS layout, browser download behaviour and opening files under school device policies must be checked on the actual demonstration laptop. The application does not require an internet connection or runtime libraries for normal operation.

No real hardware, live weather, physical heat recovery or industrial validation is claimed.
